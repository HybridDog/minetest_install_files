./install_depencies.sh
./minetest_game_upgrader.sh
./minetest_installer.sh
